# MasterBlaster - Specification Package

## Overview

MasterBlaster is a .NET 9 Windows service that automates legacy Windows applications (primarily ExportMaster) by driving them through an RDP session using Anthropic's Claude Computer Use capability. A custom scripting language (MBL) defines tasks declaratively, and Claude interprets screenshots to determine how to execute each step.

## Documents

| File | Description |
|------|-------------|
| **CONTENTS.md** | This file |
| **MBL_REFERENCE.md** | MBL language specification — syntax, keywords, semantics, examples |
| **ENGINE_SPEC.md** | MasterBlaster engine — architecture, RDP integration, Claude API, TCP interface, configuration, logging, error handling |

## Start Here

1. Read **MBL_REFERENCE.md** first — understand the scripting language that drives everything
2. Read **ENGINE_SPEC.md** — the engine that executes MBL tasks against an RDP session
3. Build in the order described in ENGINE_SPEC.md § Implementation Order

## Tech Stack

| Component | Choice | Why |
|-----------|--------|-----|
| Language | C# / .NET 9 | Aligns with existing tooling, MSTSCLib interop |
| RDP | MSTSCLib (ActiveX) | Native Windows RDP control, no external dependencies |
| AI | Anthropic Claude API (Computer Use) | Screenshot interpretation and action planning |
| Default model | Claude Sonnet | Balance of speed, cost, and visual capability |
| Transport | TCP (localhost) | Service accepts task requests as JSON over TCP |
| Task language | MBL (.mbl files) | Custom declarative language defined in MBL_REFERENCE.md |
| Logging | Structured JSON | Every action, screenshot, API call logged |

## Key Concepts

- **MBL tasks are templates** — they define the steps, callers provide the parameters
- **MasterBlaster is a tool, not a platform** — no database access, no scheduling, no batch management
- **Claude sees the screen** — `expect` statements ask Claude to visually confirm screen state; actions tell Claude what to do next
- **Any external program can call it** — via TCP JSON protocol or single-shot command line
- **The RDP session stays alive** — between task invocations for performance

## What MasterBlaster Is NOT

- Not a scheduler (use Windows Task Scheduler, Hangfire, cron, whatever)
- Not a database client (the caller queries databases and feeds parameters)
- Not a web server (a future web coordinator will talk to MasterBlaster over TCP)
- Not a batch manager (the caller loops and manages state)
