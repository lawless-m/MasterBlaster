# MBL Language Reference

## Overview

MBL (MasterBlaster Language) is a declarative scripting language for defining UI automation tasks. MBL files describe *what* needs to happen in human-readable terms — Claude interprets screenshots to determine *how* to execute each action.

MBL is deliberately simple. It is not a general-purpose programming language. It has no variables beyond task inputs and extracted values, no arithmetic, no string manipulation, and no complex control flow. Heavy logic belongs in the calling program, not in MBL.

## File Convention

- Extension: `.mbl`
- Location: configurable tasks directory (default `./tasks/`)
- Encoding: UTF-8
- Task name derived from filename: `create_invoice.mbl` → task name `create_invoice`
- One task per file

## Syntax Overview

MBL is whitespace-sensitive (indentation-based). Keywords are lowercase. String literals are enclosed in double quotes. Comments begin with `#`.

```
# This is a comment

task "Human-Readable Task Name"
  input param1, param2, param3

  step "Step description"
    expect "what the screen should look like"
    click "element to click"
    expect "what should happen after clicking"

  on timeout
    abort "message"

  on error
    screenshot
    abort "message"
```

## Top-Level Structure

### task

Every MBL file begins with a `task` declaration. The string is a human-readable name used in logs and error messages. The filename is the machine-readable identifier used when invoking the task.

```
task "Create Invoice"
```

### input

Declares named parameters the task requires. The caller must provide all of these. Parameter names are alphanumeric with underscores, no spaces.

```
  input order_number, invoice_template
```

Parameters can be referenced anywhere a value is needed, by name:

```
  type order_number into "order reference field"
```

### step

A named group of actions executed sequentially. The string is a human-readable description for logging and error reporting.

```
  step "Enter customer details"
    expect "customer form is open"
    type customer_name into "name field"
```

Steps execute in document order. If any action within a step fails (after retries), execution moves to the `on error` handler.

### on timeout

Handler invoked when an `expect` statement exhausts all retries without matching. Optional — if omitted, timeout is treated as an error and falls through to `on error`.

```
  on timeout
    screenshot
    abort "Timed out waiting for screen state"
```

### on error

Handler invoked when an unexpected error occurs (action fails, Claude returns an error, etc.). Optional — if omitted, the task fails with a generic error.

```
  on error
    screenshot
    abort "Unexpected screen state encountered"
```

## Action Keywords

### expect

Asks Claude to examine the current screenshot and confirm the described state. This is the core mechanism — Claude receives the screenshot and the natural language description, and responds with whether the screen matches.

```
  expect "main menu is visible"
  expect "customer list screen is loaded with search box at top"
  expect "invoice has been generated and invoice number is visible"
```

**Behaviour:**
1. Capture screenshot from RDP session
2. Send screenshot + expect description to Claude
3. Claude responds: match / no match / uncertain
4. On match: proceed to next action
5. On no match: wait and retry (see Retry Behaviour below)
6. On uncertain: retry, then escalate to timeout/error handler

**Retry behaviour:**
- Default timeout: 10 seconds total
- Retry intervals: screenshot at 1s, 2s, 4s, then fail
- Per-step override available with `timeout` keyword (see below)

**Claude prompt for expect (engine constructs this):**
```
Look at this screenshot. Does the following description match what you see?

Description: "customer list screen is loaded with search box at top"

Respond with:
- MATCH if the description accurately reflects the current screen state
- NO_MATCH if the screen clearly shows something different
- UNCERTAIN if you cannot confidently determine either way

If NO_MATCH, briefly describe what you actually see.
```

### click

Asks Claude to identify and click an element described in natural language.

```
  click "Customers menu item"
  click "Save button"
  click "New Customer button"
```

**Behaviour:**
1. Send current screenshot + click description to Claude
2. Claude identifies the element and returns coordinates
3. Engine sends mouse click at those coordinates via MSTSCLib
4. Short pause (configurable, default 500ms) to allow UI response

### double-click

Same as `click` but sends a double-click.

```
  double-click "customer row for account ABC123"
```

### right-click

Same as `click` but sends a right-click. Useful for context menus.

```
  right-click "selected invoice row"
```

### type

Types text into a field identified by description. The value can be a literal string or an input parameter name.

```
  type "John Smith" into "customer name field"
  type customer_name into "customer name field"
  type postcode into "postcode field"
```

**Behaviour:**
1. Send current screenshot + field description to Claude
2. Claude identifies the field and returns coordinates
3. Engine clicks the field to focus it
4. Engine clears any existing content (Ctrl+A, Delete)
5. Engine types the text character by character via MSTSCLib key events
6. Short pause after completion

**Note:** The clear-before-type behaviour (step 4) can be suppressed with the `append` modifier:

```
  type " additional text" append into "notes field"
```

### select

Selects a value from a dropdown or combo box.

```
  select "EUROLAND4" in "template dropdown"
  select invoice_template in "template dropdown"
```

**Behaviour:**
1. Send screenshot + dropdown description to Claude
2. Claude identifies the dropdown and returns coordinates
3. Engine clicks to open the dropdown
4. Capture new screenshot showing dropdown options
5. Send screenshot + desired value to Claude
6. Claude identifies the option and returns coordinates
7. Engine clicks the option

This is a two-phase operation because dropdowns change the screen.

### key

Sends a keyboard shortcut or key press.

```
  key Tab
  key Enter
  key Escape
  key Ctrl+S
  key Alt+F4
  key F5
```

**Supported key names:**
- Letters and numbers: `A`-`Z`, `0`-`9`
- Function keys: `F1`-`F12`
- Navigation: `Tab`, `Enter`, `Escape`, `Space`, `Backspace`, `Delete`
- Arrows: `Up`, `Down`, `Left`, `Right`
- Modifiers: `Home`, `End`, `PageUp`, `PageDown`
- Combinations using `+`: `Ctrl+S`, `Alt+F4`, `Ctrl+Shift+N`, `Ctrl+A`

### extract

Asks Claude to read a value from the screen and store it as a named output.

```
  extract invoice_number from "invoice number field"
  extract customer_number from "customer number field at top of form"
  extract total_amount from "invoice total in the bottom right"
```

**Behaviour:**
1. Send current screenshot + field/area description to Claude
2. Claude identifies the element and reads the text value
3. Value stored internally, available to subsequent steps and as output

### output

Declares that an extracted value should be returned to the caller in the task result.

```
  output invoice_number
  output customer_number
```

Multiple outputs are supported. Values must have been previously `extract`ed.

### screenshot

Captures and saves a screenshot to the log directory. Typically used in error handlers for diagnostic purposes. The screenshot is saved to disk — it is not shown to anyone in real time.

```
  on error
    screenshot
    abort "Something went wrong"
```

### abort

Immediately terminates the task with a failure status and the given message.

```
  abort "Could not find the expected screen"
```

## Control Flow

### timeout (per-step)

Overrides the default expect timeout for a specific step. Value in seconds.

```
  step "Wait for slow report generation"
    timeout 60
    click "Generate Report button"
    expect "report has finished generating"
```

### if screen shows ... then ... end

Conditional branching for handling UI quirks like dialog boxes, warnings, or variable screen states. This is NOT general-purpose branching — it is specifically for when the screen might be in one of several known states.

```
  step "Handle possible duplicate warning"
    if screen shows "duplicate customer warning dialog"
      click "Continue Anyway button"
    end
    expect "blank customer entry form is open"
```

**Behaviour:**
1. Capture screenshot
2. Ask Claude if the described state is present
3. If yes: execute the indented actions
4. If no: skip to after `end`
5. Continue with subsequent actions regardless

Nesting is not supported. Keep it simple — if the branching gets complex, the task should be split into multiple tasks and the caller should handle the logic.

### if ... else ... end

For cases where the screen could be in one of exactly two states:

```
  step "Check customer type"
    if screen shows "trade customer form"
      type trade_discount into "discount field"
    else
      type retail_markup into "markup field"
    end
```

## Parameter References

Input parameters and extracted values are referenced by name wherever a value is expected:

```
task "Create Invoice"
  input order_number, invoice_template

  step "Enter order"
    type order_number into "order reference field"
    select invoice_template in "template dropdown"

  step "Capture result"
    extract invoice_number from "invoice number field"
    output invoice_number
```

Parameter names must be alphanumeric with underscores. They are case-sensitive.

## Complete Example

```
# Create an invoice in ExportMaster for a given order and template
# Called by: invoice processing service
# Inputs: order_number (e.g. "Z6446"), invoice_template (e.g. "EUROLAND4")
# Outputs: invoice_number (the generated invoice number)

task "Create Invoice"
  input order_number, invoice_template

  step "Navigate to invoicing"
    expect "main menu or desktop is visible"
    click "Invoicing menu item"
    expect "invoicing screen is loaded"

  step "Select template"
    click "template selector"
    select invoice_template in "template dropdown"
    expect "template is selected and form is ready"

  step "Enter order reference"
    type order_number into "order reference field"
    key Enter
    expect "order details have been loaded and line items are visible"

  step "Handle possible credit hold warning"
    if screen shows "credit hold warning dialog"
      click "Override button"
      expect "warning dismissed and invoice form is visible"
    end

  step "Generate invoice"
    click "Create Invoice button"
    expect "invoice has been generated successfully"

  step "Capture invoice number"
    extract invoice_number from "invoice number field"
    output invoice_number

  step "Return to menu"
    key Escape
    expect "invoicing screen or main menu is visible"

  on timeout
    screenshot
    abort "Timed out waiting for ExportMaster to respond"

  on error
    screenshot
    abort "Unexpected screen state in ExportMaster"
```

## Second Example — Data Entry with Multiple Fields

```
# Create a new customer record in ExportMaster
# Inputs: name, account_type, postcode
# Outputs: customer_number (assigned by ExportMaster)

task "Create New Customer"
  input name, account_type, postcode

  step "Open customer screen"
    expect "main menu is visible"
    click "Customers menu item"
    expect "customer list screen is loaded"

  step "Start new record"
    expect "toolbar is visible and New button is enabled"
    click "New Customer button"
    expect "blank customer entry form is open"

  step "Enter details"
    type name into "customer name field"
    select account_type in "account type dropdown"
    type postcode into "postcode field"
    key Tab
    expect "address fields have been populated by postcode lookup"

  step "Save"
    click "Save button"
    expect "record saved successfully and customer number is visible"
    extract customer_number from "customer number field"
    output customer_number

  on timeout
    abort "Timed out waiting for screen state"

  on error
    screenshot
    abort "Unexpected screen state encountered"
```

## Grammar Summary

```
file            = comment* task_decl input_decl? step+ error_handler*
task_decl       = "task" STRING
input_decl      = "input" IDENT ("," IDENT)*
step            = "step" STRING timeout_decl? action+
timeout_decl    = "timeout" INTEGER
action          = expect | click | double_click | right_click | type_action
                | select_action | key_action | extract | output
                | screenshot | abort | if_block
expect          = "expect" STRING
click           = "click" STRING
double_click    = "double-click" STRING
right_click     = "right-click" STRING
type_action     = "type" value "append"? "into" STRING
select_action   = "select" value "in" STRING
key_action      = "key" KEY_COMBO
extract         = "extract" IDENT "from" STRING
output          = "output" IDENT
screenshot      = "screenshot"
abort           = "abort" STRING
if_block        = "if" "screen" "shows" STRING action+ ("else" action+)? "end"
error_handler   = ("on" "timeout" | "on" "error") action+
value           = STRING | IDENT
comment         = "#" TEXT NEWLINE

STRING          = '"' [^"]* '"'
IDENT           = [a-zA-Z_][a-zA-Z0-9_]*
INTEGER         = [0-9]+
KEY_COMBO       = KEY ("+" KEY)*
KEY             = "Tab" | "Enter" | "Escape" | "Space" | "F1" .. "F12"
                | "Ctrl" | "Alt" | "Shift" | "Up" | "Down" | "Left" | "Right"
                | "Home" | "End" | "PageUp" | "PageDown" | "Backspace" | "Delete"
                | [A-Z] | [0-9]
```

## Reserved for Future Use

These are NOT implemented in v1 but are noted as potential future additions:

- `wait` INTEGER — explicit pause in seconds (avoid — prefer `expect` with timeout)
- `loop` ... `end` — repeat a block (caller should handle loops instead)
- `log` STRING — write to task log (engine logs everything anyway)
- `ask` STRING — pause and prompt the human operator (future web coordinator feature)
