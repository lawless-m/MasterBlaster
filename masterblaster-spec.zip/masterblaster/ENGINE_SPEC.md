# MasterBlaster Engine Specification

## Overview

MasterBlaster is a .NET 9 Windows application that executes MBL task files against a legacy Windows application running in an RDP session. It uses Anthropic's Claude API with Computer Use capability to interpret screenshots and determine how to execute UI actions.

## Architecture

```
                                    ┌─────────────────┐
  External Caller ──── TCP ────────►│  MasterBlaster   │
  (any language)    JSON protocol   │     Service      │
                                    │                  │
                                    │  ┌────────────┐  │
                                    │  │ MBL Parser │  │
                                    │  └─────┬──────┘  │
                                    │        │         │
                                    │  ┌─────▼──────┐  │
                                    │  │  Task      │  │
                                    │  │  Executor  │  │
                                    │  └──┬─────┬───┘  │
                                    │     │     │      │
                                    │  ┌──▼──┐ ┌▼───┐  │
                                    │  │ RDP │ │API │  │
                                    │  │Ctrl │ │Ctrl│  │
                                    │  └──┬──┘ └─┬──┘  │
                                    └─────┼──────┼─────┘
                                          │      │
                              MSTSCLib    │      │  HTTPS
                                          │      │
                                    ┌─────▼──┐ ┌─▼──────────┐
                                    │ Target │ │  Anthropic  │
                                    │   VM   │ │  Claude API │
                                    └────────┘ └─────────────┘
```

## Components

### 1. TCP Listener

Accepts task requests and returns results over TCP.

**Binding:** Configurable host and port (default `127.0.0.1:9500`).

**Protocol:** Newline-delimited JSON. Each message is a single JSON object terminated by `\n`. The connection stays open for multiple requests (one at a time — tasks execute sequentially).

**Request format:**

```json
{
  "action": "run",
  "task": "create_invoice",
  "params": {
    "order_number": "Z6446",
    "invoice_template": "EUROLAND4"
  }
}
```

**Response format (success):**

```json
{
  "status": "success",
  "task": "create_invoice",
  "outputs": {
    "invoice_number": "INV-2026-001234"
  },
  "duration_ms": 14500,
  "steps_completed": 6,
  "steps_total": 6,
  "log_file": "logs/2026-02-17_143022_create_invoice.json"
}
```

**Response format (failure):**

```json
{
  "status": "error",
  "task": "create_invoice",
  "error": "Timed out waiting for ExportMaster to respond",
  "failed_at_step": "Enter order reference",
  "screenshot": "screenshots/error_20260217_143052.png",
  "duration_ms": 18200,
  "steps_completed": 2,
  "steps_total": 6,
  "log_file": "logs/2026-02-17_143022_create_invoice.json"
}
```

**Control commands:**

```json
{"action": "status"}
```
Returns current state: idle, executing (which task, which step), connected/disconnected.

```json
{"action": "shutdown"}
```
Gracefully disconnects RDP and shuts down.

```json
{"action": "reconnect"}
```
Disconnects and reconnects the RDP session (useful if the VM state gets confused).

```json
{"action": "list_tasks"}
```
Returns available task names from the tasks directory.

```json
{"action": "screenshot"}
```
Captures and saves a screenshot immediately, returns the path. Diagnostic tool.

### 2. Single-Shot CLI Mode

For testing and one-off tasks:

```
masterblaster run create_invoice --order_number Z6446 --invoice_template EUROLAND4
```

**Behaviour:**
1. Connects to RDP
2. Loads and executes the task
3. Prints result JSON to stdout
4. Disconnects and exits
5. Exit code: 0 for success, 1 for task failure, 2 for engine error

**Also supports:**

```
masterblaster validate create_invoice
```
Parses the MBL file and reports syntax errors without executing.

```
masterblaster list
```
Lists available tasks.

```
masterblaster service
```
Starts in service/daemon mode (TCP listener).

### 3. MBL Parser

Parses `.mbl` files into an in-memory task representation.

**Input:** Raw MBL text from file.

**Output:** A `TaskDefinition` object:

```csharp
public record TaskDefinition
{
    public string Name { get; init; }              // "Create Invoice"
    public string FileName { get; init; }          // "create_invoice"
    public List<string> Inputs { get; init; }      // ["order_number", "invoice_template"]
    public List<Step> Steps { get; init; }
    public ErrorHandler? OnTimeout { get; init; }
    public ErrorHandler? OnError { get; init; }
}

public record Step
{
    public string Description { get; init; }       // "Navigate to invoicing"
    public int? TimeoutSeconds { get; init; }      // null = use default
    public List<IAction> Actions { get; init; }
}

public interface IAction { }

public record ExpectAction(string Description) : IAction;
public record ClickAction(string Target) : IAction;
public record DoubleClickAction(string Target) : IAction;
public record RightClickAction(string Target) : IAction;
public record TypeAction(string Value, bool IsParam, string Target, bool Append) : IAction;
public record SelectAction(string Value, bool IsParam, string Target) : IAction;
public record KeyAction(string KeyCombo) : IAction;
public record ExtractAction(string VariableName, string Source) : IAction;
public record OutputAction(string VariableName) : IAction;
public record ScreenshotAction() : IAction;
public record AbortAction(string Message) : IAction;
public record IfScreenShowsAction(string Condition, List<IAction> Then, List<IAction>? Else) : IAction;

public record ErrorHandler
{
    public List<IAction> Actions { get; init; }
}
```

**Validation (at parse time):**
- All `output` names must have a corresponding `extract` earlier in the task
- All parameter references in `type` and `select` must be declared in `input`
- `if` blocks must not be nested
- At least one `step` is required
- Syntax errors produce clear messages with line numbers

### 4. Task Executor

Runs a parsed `TaskDefinition` with provided parameters against the RDP session.

**Execution loop per action:**

```
For each step in task:
  Log step start
  Set step timeout (per-step or default)
  For each action in step:
    Execute action (see action handlers below)
    If action fails:
      If retries remaining: wait, retry
      Else: invoke error handler
  Log step complete
```

**State maintained during execution:**
- Current step name and index
- Extracted values (Dictionary<string, string>)
- Declared outputs (List<string>)
- Elapsed time
- All screenshots captured (for logging)

**Action handlers:**

| Action | Handler |
|--------|---------|
| `expect` | Capture screenshot → send to Claude with expect prompt → evaluate response → retry on no-match |
| `click` | Capture screenshot → send to Claude asking for element coordinates → send click via RDP |
| `double-click` | Same as click but double-click event |
| `right-click` | Same as click but right-click event |
| `type` | Capture screenshot → ask Claude for field coordinates → click to focus → Ctrl+A, Delete (unless append) → send keystrokes |
| `select` | Capture screenshot → ask Claude for dropdown coordinates → click dropdown → capture new screenshot → ask Claude for option coordinates → click option |
| `key` | Send key combination directly via RDP (no screenshot needed) |
| `extract` | Capture screenshot → ask Claude to read the value → store in extracted values dict |
| `output` | Mark an extracted value for inclusion in the task result |
| `screenshot` | Capture and save screenshot to disk |
| `abort` | Throw task abort exception with message |
| `if screen shows` | Capture screenshot → ask Claude if condition is visible → execute then/else block accordingly |

### 5. RDP Controller

Manages the MSTSCLib ActiveX control for the RDP connection.

**Responsibilities:**
- Connect to target VM
- Maintain session across multiple task executions
- Capture screenshots as bitmap images
- Send mouse events (click, double-click, right-click at x,y coordinates)
- Send keyboard events (individual keys and combinations)
- Detect disconnection and reconnect

**MSTSCLib Integration:**

```csharp
// Core interface — the actual MSTSCLib calls are wrapped behind this
public interface IRdpController
{
    Task ConnectAsync(RdpConnectionConfig config);
    Task DisconnectAsync();
    bool IsConnected { get; }
    
    // Screenshot
    Task<byte[]> CaptureScreenshotAsync();  // Returns PNG bytes
    
    // Mouse
    Task ClickAsync(int x, int y);
    Task DoubleClickAsync(int x, int y);
    Task RightClickAsync(int x, int y);
    
    // Keyboard
    Task SendKeysAsync(string text);         // Type text character by character
    Task SendKeyComboAsync(string combo);    // e.g. "Ctrl+A", "Tab", "Enter"
    
    // Events
    event EventHandler Disconnected;
    event EventHandler Connected;
}
```

**Important implementation notes:**

- MSTSCLib is a COM/ActiveX control and requires an STA thread with a message pump. The service must host a hidden WinForms form or equivalent to provide this.
- Screenshot capture uses the `IMsRdpClient` interface to grab the session bitmap. The exact mechanism depends on the MSTSCLib version — some versions expose `CreateVirtualChannels`, others need the `IMsRdpClientNonScriptable` interface for bitmap access.
- Key sending must use `IMsRdpClientNonScriptable.SendKeys` or equivalent scancode-level injection, NOT clipboard paste. The target application needs actual keystrokes.
- Mouse coordinates are relative to the RDP session viewport, which must match what Claude sees in the screenshot. The screenshot resolution and the RDP session resolution MUST be the same.

**RDP session resolution:**
Configure the RDP session to a fixed resolution (e.g. 1920×1080 or 1280×1024) so screenshots are consistent and Claude can reliably map coordinates. This is set in the connection config, not auto-detected.

**Connection config:**

```csharp
public record RdpConnectionConfig
{
    public string Server { get; init; }          // hostname or IP
    public int Port { get; init; } = 3389;
    public string Username { get; init; }
    public string Password { get; init; }         // or use credential store
    public string Domain { get; init; }
    public int Width { get; init; } = 1920;
    public int Height { get; init; } = 1080;
    public int ColorDepth { get; init; } = 32;
}
```

### 6. Claude API Controller

Manages communication with Anthropic's Claude API for Computer Use.

**Responsibilities:**
- Send screenshots to Claude with structured prompts
- Parse Claude's responses (coordinates, text values, match/no-match)
- Manage conversation context within a task execution
- Handle rate limiting and retries
- Track token usage for cost monitoring

**API integration:**

Uses the Anthropic .NET SDK (or direct HTTP if SDK is insufficient for Computer Use features).

**Model selection:**
- Default: `claude-sonnet-4-5-20250929` (fast, cost-effective for visual tasks)
- Configurable per-task or globally for cases needing more intelligence
- Token budget per task configurable (default: 100,000 tokens — a rough ceiling, not a hard limit)

**Prompt strategy:**

Each action type sends a specific prompt structure. The engine does NOT maintain a running conversation across the entire task — each action is a fresh API call with:
1. A system prompt explaining the role
2. The current screenshot as an image
3. The specific instruction for this action

This is stateless per action. Claude does not need to remember previous steps — the screenshot IS the state.

**System prompt (shared across all action types):**

```
You are an automation assistant controlling a legacy Windows application 
called ExportMaster through an RDP session. You are looking at a screenshot 
of the application and will be asked to perform specific actions.

The screenshot resolution is {width}x{height} pixels. When asked to identify 
UI elements, respond with precise pixel coordinates. When asked to read text, 
respond with the exact text visible on screen.

Be precise. Legacy Windows applications have small click targets — buttons, 
menu items, and fields may be close together. Identify the correct element 
carefully.
```

**Per-action prompts:**

**expect:**
```
Look at this screenshot. Does the following description match what you see?

Description: "{description}"

Respond with exactly one of:
MATCH - if the description accurately reflects the current screen state
NO_MATCH - if the screen clearly shows something different  
UNCERTAIN - if you cannot confidently determine either way

If NO_MATCH, on the next line briefly describe what you actually see.
```

**click / double-click / right-click:**
```
Look at this screenshot. I need to click on the following element:

Element: "{target}"

Respond with the pixel coordinates of the centre of this element in the format:
x,y

If you cannot find this element, respond with:
NOT_FOUND: brief description of what you see instead
```

**type (finding the field):**
```
Look at this screenshot. I need to type text into the following field:

Field: "{target}"

Respond with the pixel coordinates of the centre of this field in the format:
x,y

If you cannot find this field, respond with:
NOT_FOUND: brief description of what you see instead
```

**select (finding the dropdown):**
```
Look at this screenshot. I need to select a value from the following dropdown:

Dropdown: "{target}"

Respond with the pixel coordinates of the centre of this dropdown in the format:
x,y

If you cannot find this dropdown, respond with:
NOT_FOUND: brief description of what you see instead
```

**select (finding the option after dropdown is open):**
```
Look at this screenshot. The dropdown is now open. I need to select:

Option: "{value}"

Respond with the pixel coordinates of this option in the format:
x,y

If you cannot find this option in the dropdown, respond with:
NOT_FOUND: list the options you can see
```

**extract:**
```
Look at this screenshot. I need to read the value from:

Field: "{source}"

Respond with just the text value you can see in this field. 
If the field is empty, respond with: EMPTY
If you cannot find the field, respond with: NOT_FOUND
```

**if screen shows:**
```
Look at this screenshot. Is the following visible?

Condition: "{condition}"

Respond with exactly: YES or NO
```

**Response parsing:**

Claude's responses are parsed strictly. The engine expects specific formats per action type:
- Coordinates: regex `^(\d+),(\d+)$`
- Match result: exact string `MATCH`, `NO_MATCH`, or `UNCERTAIN`
- Boolean: exact string `YES` or `NO`
- Extract: any text (trimmed)
- Error: strings starting with `NOT_FOUND` or `EMPTY`

If the response doesn't match the expected format, it's treated as an error and retried once with a clarification prompt.

### 7. Logger

Structured JSON logging for every operation.

**Log file per task execution:**
```
logs/2026-02-17_143022_create_invoice.json
```

**Log entry format:**

```json
{
  "timestamp": "2026-02-17T14:30:22.456Z",
  "level": "info",
  "event": "action_execute",
  "task": "create_invoice",
  "step": "Enter order reference",
  "step_index": 2,
  "action": "type",
  "action_detail": {
    "value": "Z6446",
    "target": "order reference field"
  },
  "screenshot": "screenshots/2026-02-17_143022_step2_action1.png",
  "claude_request_tokens": 1847,
  "claude_response_tokens": 12,
  "claude_response": "645,312",
  "claude_model": "claude-sonnet-4-5-20250929",
  "duration_ms": 1234
}
```

**What gets logged:**
- Every screenshot captured (saved to disk, path logged)
- Every Claude API call (prompt summary, response, token counts, latency)
- Every action attempted and its result
- Step start/complete/fail events
- Task start/complete/fail events
- TCP requests received and responses sent
- RDP connection/disconnection events
- Errors and retries

**Screenshot storage:**
```
screenshots/
├── 2026-02-17_143022_step1_expect1.png
├── 2026-02-17_143022_step2_click1.png
├── 2026-02-17_143022_step2_type1.png
├── error_20260217_143052.png
```

**Log rotation:**
Configurable retention. Default: keep 30 days of logs and screenshots. Older files deleted on startup.

## Configuration

Single JSON configuration file. Path configurable via command-line argument (default: `./config.json`).

```json
{
  "tcp": {
    "host": "127.0.0.1",
    "port": 9500
  },

  "rdp": {
    "server": "exportmaster-vm",
    "port": 3389,
    "username": "automation_user",
    "password_env": "MB_RDP_PASSWORD",
    "domain": "CORP",
    "width": 1920,
    "height": 1080,
    "color_depth": 32
  },

  "claude": {
    "api_key_env": "ANTHROPIC_API_KEY",
    "model": "claude-sonnet-4-5-20250929",
    "max_tokens_per_request": 1024,
    "token_budget_per_task": 100000,
    "retry_on_rate_limit": true,
    "rate_limit_backoff_ms": 5000
  },

  "tasks": {
    "directory": "./tasks",
    "default_expect_timeout_seconds": 10,
    "expect_retry_intervals_ms": [1000, 2000, 4000],
    "post_action_delay_ms": 500,
    "post_click_delay_ms": 500,
    "typing_delay_ms": 50
  },

  "logging": {
    "directory": "./logs",
    "screenshot_directory": "./screenshots",
    "retention_days": 30,
    "log_level": "info"
  }
}
```

**Sensitive values:**
Passwords and API keys are NEVER stored in the config file. They are referenced by environment variable name using the `_env` suffix convention. The engine reads the environment variable at startup.

## Error Handling

### Action-Level Retry

When an action fails (Claude returns NOT_FOUND, coordinates are outside viewport, etc.):
1. Wait 1 second
2. Capture a fresh screenshot
3. Retry the action
4. If it fails again: move to step-level error handling

### Step-Level (expect timeout)

When an `expect` fails to match:
1. Retry at configured intervals (default: 1s, 2s, 4s)
2. Each retry captures a fresh screenshot
3. If all retries exhausted: invoke `on timeout` handler if defined, otherwise invoke `on error` handler
4. If neither handler is defined: task fails with generic timeout error

### Task-Level (on error / on timeout)

Error handlers execute their action list (typically `screenshot` then `abort`). The `abort` action sets the task result to failure with the given message.

If the error handler itself throws an error, the task fails with an engine-level error.

### Engine-Level

Errors in the engine itself (RDP disconnection, Claude API unreachable, malformed config):
- Logged
- Current task (if any) fails with engine error status
- TCP connection informed
- In service mode: engine attempts recovery (reconnect RDP, retry API)
- In CLI mode: exit with code 2

### RDP Disconnection

If the RDP session drops during task execution:
1. Current task fails immediately (no point retrying UI actions without a session)
2. Engine attempts to reconnect
3. Next task request can proceed once reconnected
4. TCP status command reflects disconnected/reconnecting state

## Security Considerations

- TCP listener binds to localhost only by default. Exposing to network requires explicit configuration.
- RDP credentials stored in environment variables, not config files.
- API key stored in environment variable.
- Log files may contain sensitive data visible in screenshots (customer names, order numbers, etc.). Log directory should have appropriate filesystem permissions.
- The automation user on the target VM should have minimum necessary permissions in ExportMaster.

## Performance Considerations

- Each Claude API call takes roughly 1–3 seconds depending on model and image size.
- A typical task step with expect + action = 2 API calls = 2–6 seconds.
- A 6-step task might take 30–60 seconds.
- Batch processing 50 invoices: expect 25–50 minutes.
- Screenshots at 1920×1080 are roughly 200–500KB as PNG. Claude handles these well.
- Token usage per action: roughly 1500–2500 tokens (mostly the image). Budget accordingly.
- The `post_action_delay_ms` setting prevents clicking too fast for the legacy application. Tune per-application.

## Project Structure

```
MasterBlaster/
├── MasterBlaster.sln
├── src/
│   ├── MasterBlaster/
│   │   ├── Program.cs                    # Entry point, CLI parsing
│   │   ├── MasterBlaster.csproj
│   │   ├── Config/
│   │   │   ├── AppConfig.cs              # Configuration model
│   │   │   └── ConfigLoader.cs           # JSON config + env var resolution
│   │   ├── Tcp/
│   │   │   ├── TcpServer.cs              # TCP listener
│   │   │   ├── Protocol.cs               # Request/Response models
│   │   │   └── RequestHandler.cs         # Routes requests to executor
│   │   ├── Mbl/
│   │   │   ├── Lexer.cs                  # Tokeniser
│   │   │   ├── Parser.cs                 # MBL parser
│   │   │   ├── TaskDefinition.cs         # Parsed task model
│   │   │   ├── Actions.cs                # Action type definitions
│   │   │   └── Validator.cs              # Semantic validation
│   │   ├── Rdp/
│   │   │   ├── IRdpController.cs         # Interface
│   │   │   ├── MstscRdpController.cs     # MSTSCLib implementation
│   │   │   └── RdpHostForm.cs            # Hidden WinForms host for ActiveX
│   │   ├── Claude/
│   │   │   ├── IClaudeClient.cs          # Interface
│   │   │   ├── ClaudeClient.cs           # Anthropic API client
│   │   │   ├── PromptBuilder.cs          # Constructs prompts per action type
│   │   │   └── ResponseParser.cs         # Parses Claude responses
│   │   ├── Execution/
│   │   │   ├── TaskExecutor.cs           # Main execution loop
│   │   │   ├── ActionHandlers/
│   │   │   │   ├── ExpectHandler.cs
│   │   │   │   ├── ClickHandler.cs
│   │   │   │   ├── TypeHandler.cs
│   │   │   │   ├── SelectHandler.cs
│   │   │   │   ├── KeyHandler.cs
│   │   │   │   ├── ExtractHandler.cs
│   │   │   │   └── IfScreenShowsHandler.cs
│   │   │   └── ExecutionContext.cs        # Per-task state
│   │   └── Logging/
│   │       ├── TaskLogger.cs             # Structured JSON logger
│   │       └── ScreenshotManager.cs      # Capture and store screenshots
│   └── MasterBlaster.Tests/
│       ├── Mbl/
│       │   ├── LexerTests.cs
│       │   ├── ParserTests.cs
│       │   └── ValidatorTests.cs
│       ├── Claude/
│       │   ├── PromptBuilderTests.cs
│       │   └── ResponseParserTests.cs
│       └── Tcp/
│           └── ProtocolTests.cs
├── tasks/
│   ├── create_invoice.mbl
│   └── create_customer.mbl
├── config.json
└── README.md
```

## Dependencies (NuGet)

| Package | Purpose |
|---------|---------|
| `System.CommandLine` | CLI argument parsing |
| `System.Text.Json` | JSON serialization |
| `Microsoft.Extensions.Logging` | Logging abstractions |
| `AxInterop.MSTSCLib` / `Interop.MSTSCLib` | RDP ActiveX control (COM reference) |
| `Anthropic.SDK` | Claude API client (evaluate — may need direct HTTP for Computer Use) |

**Note on Anthropic SDK:** The official .NET SDK may not support Computer Use tool calls. If not, use `HttpClient` directly against the API. The Claude controller should be behind an interface regardless, so swapping implementations is straightforward.

**Note on MSTSCLib:** This is a COM reference, not a NuGet package. Added via `Add COM Reference` → `Microsoft Terminal Services Client Control`. The interop assemblies are generated at build time.

## Implementation Order

Build in this order. Each stage is testable independently.

1. **MBL Parser + Validator** — parse files, validate semantics, produce TaskDefinition objects. Fully testable without RDP or Claude.

2. **Response Parser** — parse Claude's response formats (coordinates, MATCH/NO_MATCH, text). Fully testable with string inputs.

3. **Prompt Builder** — generate the correct prompt for each action type. Testable by asserting prompt text content.

4. **Claude Client** — connect to Anthropic API, send image + prompt, get response. Test with a real API key against a sample screenshot.

5. **RDP Controller** — connect to a VM, capture screenshots, send clicks and keystrokes. Test manually against a running VM.

6. **Task Executor** — wire parser + Claude + RDP together. Execute a simple task (hardcoded) against a real VM.

7. **TCP Server** — accept JSON requests, route to executor, return results. Test with a TCP client sending JSON.

8. **CLI Mode** — parse command-line arguments, execute single task, print result.

9. **Integration testing** — run example tasks (create_invoice, create_customer) against ExportMaster.

## Future Considerations (Out of Scope for v1)

- **Web coordinator UI** — a separate application that provides a browser-based interface for monitoring, launching tasks, reviewing errors. Talks to MasterBlaster over TCP.
- **Task chaining** — output from one task feeds as input to another. Currently the caller handles this.
- **Parallel execution** — multiple RDP sessions running tasks simultaneously. Would require multiple MSTSCLib instances.
- **Task recording** — watch a human operate ExportMaster and generate an MBL file from the observed actions.
- **Confidence thresholds** — tune how confident Claude must be before acting (currently binary match/no-match).
- **`ask` keyword** — pause execution and ask the human operator for guidance via the web coordinator.
